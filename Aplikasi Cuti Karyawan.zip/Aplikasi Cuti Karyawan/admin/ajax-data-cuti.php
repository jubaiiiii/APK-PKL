<?php
include "koneksi.php";

$requestData = $_REQUEST;

$columns = array( 
    0 => 'kode',
    1 => 'nik', 
    2 => 'tanggal_awal',
    3 => 'tanggal_akhir',
    4 => 'jumlah',
    5 => 'jenis_cuti',
    6 => 'ket',
    7 => 'status'
);

$sql = "SELECT kode, nik, tanggal_awal, tanggal_akhir, jumlah, jenis_cuti, ket, status";
$sql .= " FROM cuti";

$query = mysqli_query($conn, $sql) or die("ajaxin-data-cuti.php: get Cuti");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;

if (!empty($requestData['search']['value'])) {
    $sql = "SELECT kode, nik, tanggal_awal, tanggal_akhir, jumlah, jenis_cuti, ket, status";
    $sql .= " FROM cuti";
    $sql .= " WHERE kode LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR nik LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR tanggal_awal LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR tanggal_akhir LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR jumlah LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR jenis_cuti LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR ket LIKE '".$requestData['search']['value']."%' ";
    $sql .= " OR status LIKE '".$requestData['search']['value']."%' ";
    $query = mysqli_query($conn, $sql) or die("ajax-data-cuti.php: get Cuti");
    $totalFiltered = mysqli_num_rows($query);

    $sql .= " ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
    $query = mysqli_query($conn, $sql) or die("ajax-data-cuti.php: get Cuti");
} else {    
    $sql = "SELECT kode, nik, tanggal_awal, tanggal_akhir, jumlah, jenis_cuti, ket, status";
    $sql .= " FROM cuti";
    $sql .= " ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
    $query = mysqli_query($conn, $sql) or die("ajaxin-grid-data.php: get Karyawan");   
}

$data = array();
while ($row = mysqli_fetch_array($query)) {
    $nestedData = array(); 
    $nestedData[] = $row["kode"];
    $nestedData[] = $row["nik"];
    $nestedData[] = $row["tanggal_awal"];
    $nestedData[] = $row["tanggal_akhir"];
    $nestedData[] = $row["jumlah"];
    $nestedData[] = $row["jenis_cuti"];
    $nestedData[] = $row["ket"];
    $nestedData[] = $row["status"];
    $nestedData[] = '<td><center>
                    <a href="detail-cuti.php?id='.$row['kode'].'"  data-toggle="tooltip" title="View Detail" class="btn btn-sm btn-success"> <i class="glyphicon glyphicon-search"></i> </a>
                    <a href="edit-cuti.php?id='.$row['kode'].'"  data-toggle="tooltip" title="Edit" class="btn btn-sm btn-primary"> <i class="glyphicon glyphicon-edit"></i> </a>
                    <a href="cuti.php?aksi=delete&id='.$row['kode'].'&nik='.$row['nik'].'"  data-toggle="tooltip" title="Delete" onclick="return confirm(\'Anda yakin akan menghapus data '.$row['nik'].'?\')" class="btn btn-sm btn-danger"> <i class="glyphicon glyphicon-trash"> </i> </a>
                </center></td>';        

    $data[] = $nestedData;
}

$json_data = array(
    "draw"            => intval($requestData['draw']),
    "recordsTotal"    => intval($totalData),
    "recordsFiltered" => intval($totalFiltered),
    "data"            => $data
);

echo json_encode($json_data);
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Include your head.php content here -->
</head>
<body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">
        <!-- Include your header.php content here -->
        <!-- Include your menu.php content here -->
        <!-- Include your waktu.php content here -->
        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    Cuti
                    <small>HRMS</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="active">Cuti</li>
                </ol>
            </section>
            <section class="content">
                <div class="row">
                    <section class="col-lg-12 connectedSortable">
                        <div class="box box-primary">
                            <div class="box-header">
                                <i class="ion ion-clipboard"></i>
                                <h3 class="box-title">Data Cuti Karyawan</h3>
                                <div class="box-tools pull-right"></div> 
                            </div>
                            <div class="box-body">
                                <?php
                                    if (isset($_GET['aksi']) == 'delete') {
                                        $id = $_GET['id'];
                                        $nik = $_GET['nik'];
                                        $sql = mysqli_query($conn, "SELECT * FROM cuti WHERE kode='$id'");
                                        if (mysqli_num_rows($sql) == 0) {
                                            echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data tidak ditemukan.</div>';
                                        } else {
                                            $row = mysqli_fetch_assoc($sql);
                                        }
                                        $jumlah = $row['jumlah'];
                                        $cek = mysqli_query($conn, "SELECT * FROM cuti WHERE kode='$id'");
                                        if (mysqli_num_rows($cek) == 0) {
                                            echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data tidak ditemukan.</div>';
                                        } else {
                                            $delete = mysqli_query($conn, "DELETE FROM cuti WHERE kode='$id'");
                                            $qu = mysqli_query($conn, "UPDATE karyawan SET jumlah_cuti=(jumlah_cuti+'$jumlah') WHERE nik='$nik'");
                                            if ($delete && $qu) {
                                                echo '<div class="alert alert-primary alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data berhasil dihapus.</div>';
                                            } else {
                                                echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data gagal dihapus.</div>';
                                            }
                                        }
                                    }
                                ?>
                                <a href="cuti_exportxls.php" class="btn btn-sm btn-success"><i class="fa fa-file"></i> Export Excel</a><br /><br />
                                <table id="lookup" class="table table-bordered table-hover">  
                                    <thead bgcolor="eeeeee" align="center">
                                        <tr>
                                            <th>Kode</th>
                                            <th>Nik</th>
                                            <th>Tanggal Awal</th>
                                            <th>Tanggal Akhir</th>
                                            <th>Jumlah</th>
                                            <th>Jenis Cuti</th>
                                            <th>Keterangan</th>
                                            <th>Status</th>
                                            <th class="text-center"> Action </th> 
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>  
                            </div>
                            <div class="box-footer clearfix no-border">
                                <a href="input-cuti.php" class="btn btn-sm btn-default pull-right"><i class="fa fa-plus"></i> Buat Cuti</a>
                            </div>
                        </div>
                    </section>
                </div>
            </section>
        </div>
        <!-- Include your footer.php content here -->
        <!-- Include your sidecontrol.php content here -->
        <div class="control-sidebar-bg"></div>
    </div>

    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <script src="../dist/js/app.min.js"></script>
    <script src="../dist/js/demo.js"></script>
    <script>
        $(document).ready(function() {
            var dataTable = $('#lookup').DataTable( {
                "processing": true,
                "serverSide": true,
                "ajax": {
                    url :"cuti.php",
                    type: "post",
                    error: function() {
                        $(".lookup-error").html("");
                        $("#lookup").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
                        $("#lookup_processing").css("display","none");
                    }
                }
            } );
        });
    </script>
</body>
</html>
