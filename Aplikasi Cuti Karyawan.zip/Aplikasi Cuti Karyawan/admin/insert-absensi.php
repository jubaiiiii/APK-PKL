<?php
$namafolder="../admin.php/"; // tempat menyimpan file absensi (jika ada)
include "../conn.php";

if (!empty($_POST['nik']) && !empty($_POST['tanggal'])) {
    $nik = $_POST['nik'];
    $tanggal = $_POST['tanggal'];
    $jam_masuk = $_POST['jam_masuk'];
    $jam_pulang = $_POST['jam_pulang'];
    $status = $_POST['status'];
    $keterangan = $_POST['keterangan'];
    
    $sql = "INSERT INTO Absensi (nik, tanggal, jam_masuk, jam_pulang, status, keterangan) VALUES ('$nik', '$tanggal', '$jam_masuk', '$jam_pulang', '$status', '$keterangan')";
    
    $res = mysqli_query($koneksi, $sql) or die(mysqli_error());
    
    if ($res) {
        echo "<script>alert('Data absensi berhasil dimasukkan!'); window.location = 'absensi.php'</script>";
    } else {
        echo "<script>alert('Gagal memasukkan data absensi!'); window.location = 'absensi.php'</script>";
    }
} else {
    echo "Data yang dibutuhkan tidak lengkap";
}
?>
