<?php
{
    include "../admin/koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Data Karyawan</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style type="text/css">
        body {
            font-family: Arial;
        }

        @media print{
            .no-print{
                display: none;    
            }
        }
    </style>
</head>
<body>
    <h3 style="text-align: center;">Laporan Data Karyawan</h3>
    <hr/>
    <table class="table table-striped" width="100%" border="0,5" cellspacing="0" cellpadding="4">
        <tr>
            <th>No.</th>
            <th>NIK</th>
            <th>Nama Karyawan</th>
            <th>Jabatan</th>
            <th>Status</th>
            <th>Jumlah Cuti</th>
        </tr>
        <?php
        $sqlKaryawan = mysqli_query($conn, "SELECT * FROM karyawan ORDER BY nik ASC");
        $no=1;
        while($d=mysqli_fetch_array($sqlKaryawan)){
            echo "<tr>
               <td align='center'>$no</td>
               <td align='center'>$d[nik]</td>
               <td>$d[nama]</td>
               <td>$d[jabatan]</td>
               <td>$d[status]</td>
               <td>$d[jumlah_cuti]</td>
            </tr>";
            $no++;
        }
        ?>
    </table> 

    <table width="100%" height="50%">
        <tr>
            <td></td>
            <td width="200px" height="50px">
                <p>Banjarmasin, <?php echo date('d/m/Y'); ?><br/>
                Admin,</p>
                <br/>
                <br/>
                <p>__________________</p>
                <h>Siti Zubaidah</h>
            </td>
        </tr>
    </table>        

    <button type="button" class="btn btn-primary no-print" onclick="window.print();">Cetak</button>

</body>
</html>

<?php
}
?>
