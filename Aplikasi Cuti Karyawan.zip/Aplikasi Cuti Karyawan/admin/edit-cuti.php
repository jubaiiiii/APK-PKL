<?php
include "session.php";
include "koneksi.php"; // Sesuaikan dengan file koneksi.php atau sesuaikan cara Anda terhubung ke database
?>
<!DOCTYPE html>
<html>
<?php include "head.php"; ?>

<body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">
        <?php include "header.php"; ?>
        <?php include "menu.php"; ?>
        <?php include "waktu.php"; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    Cuti
                    <small>Human Resource Management System</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="active">Cuti</li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <section class="col-lg-12 connectedSortable">
                        <div class="box box-primary">
                            <div class="box-header">
                                <i class="ion ion-clipboard"></i>
                                <h3 class="box-title">Edit Data Cuti</h3>
                                <div class="box-tools pull-right">
                                </div>
                            </div>
                            <?php
                            $kd = $_GET['kd'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM cuti WHERE kode='$kd'");
                            if (mysqli_num_rows($sql) == 0) {
                                header("Location: cuti.php");
                            } else {
                                $row = mysqli_fetch_assoc($sql);
                            }
                            if (isset($_POST['update'])) {
                                $kode = $_POST['kode'];
                                $nik = $_POST['nik'];
                                $tanggal_awal = $_POST['tanggal_awal'];
                                $tanggal_akhir = $_POST['tanggal_akhir'];
                                $jumlah = $_POST['jumlah'];
                                $jenis_cuti = $_POST['jenis_cuti'];
                                $ket = $_POST['ket'];
                                $status = $_POST['status'];

                                $update = mysqli_query($koneksi, "UPDATE cuti SET nik='$nik', tanggal_awal='$tanggal_awal', tanggal_akhir='$tanggal_akhir', jumlah='$jumlah', jenis_cuti='$jenis_cuti', ket='$ket', status='$status' WHERE kode='$kode'") or die(mysqli_error($koneksi));
                                if ($update) {
                                    echo "<script>alert('Data cuti berhasil diperbaharui!')</script>";
                                    echo "<meta http-equiv='refresh' content='0; url=cuti.php'>";
                                } else {
                                    echo "<script>alert('Data cuti gagal diperbaharui!')</script>";
                                    echo "<h1>" . mysqli_error($koneksi) . "</h1>";
                                }
                            }
                            ?>
                            <div class="box-body">
                                <form class="form-horizontal style-form" action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Kode</label>
                                        <div class="col-sm-8">
                                            <input name="kode" type="text" id="kode" class="form-control" placeholder="Kode" value="<?php echo $row['kode']; ?>" autofocus="on" readonly="readonly" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">NIK</label>
                                        <div class="col-sm-8">
                                            <input name="nik" type="text" id="nik" class="form-control" placeholder="NIK" value="<?php echo $row['nik']; ?>" autocomplete="off" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Tanggal Awal</label>
                                        <div class="col-sm-8">
                                            <input name="tanggal_awal" type="date" id="tanggal_awal" class="form-control" value="<?php echo $row['tanggal_awal']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Tanggal Akhir</label>
                                        <div class="col-sm-8">
                                            <input name="tanggal_akhir" type="date" id="tanggal_akhir" class="form-control" value="<?php echo $row['tanggal_akhir']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jumlah</label>
                                        <div class="col-sm-8">
                                            <input name="jumlah" type="text" id="jumlah" class="form-control" value="<?php echo $row['jumlah']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jenis Cuti</label>
                                        <div class="col-sm-8">
                                        <select name="jenis_cuti" class="form-control">
                                                <option value="Cuti Bersama" <?php echo ($row['jenis_cuti'] == 'Cuti Bersama') ? 'selected' : ''; ?>>Cuti Bersama</option>
                                                <option value="Cuti Mendadak" <?php echo ($row['jenis_cuti'] == 'Cuti Mendadak') ? 'selected' : ''; ?>>Cuti Mendadak</option>
                                                <option value="Cuti Melahirkan" <?php echo ($row['jenis_cuti'] == 'Cuti Melahirkan') ? 'selected' : ''; ?>>Cuti Melahirkan</option>
                                                <option value="Cuti Hamil" <?php echo ($row['jenis_cuti'] == 'Cuti Hamil') ? 'selected' : ''; ?>>Cuti Hamil</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Keterangan</label>
                                        <div class="col-sm-8">
                                            <input name="ket" type="text" id="ket" class="form-control" value="<?php echo $row['ket']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Status</label>
                                        <div class="col-sm-8">
                                            <select name="status" class="form-control">
                                                <option value="Approved" <?php echo ($row['status'] == 'Approved') ? 'selected' : ''; ?>>Approved</option>
                                                <option value="Rejected" <?php echo ($row['status'] == 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
                                                <option value="Pending" <?php echo ($row['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label"></label>
                                        <div class="col-sm-10">
                                            <input type="submit" name="update" value="Simpan" class="btn btn-sm btn-primary" />&nbsp;
                                            <a href="cuti.php" class="btn btn-sm btn-danger">Batal </a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </section>
        </div>

        <?php include "footer.php"; ?>
        <?php include "sidecontrol.php"; ?>
        <div class="control-sidebar-bg"></div>
    </div>

    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="../css/jquery-ui.min.js"></script>
    <script>
        $.widget.bridge('uibutton', $.ui.button);
    </script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="../plugins/morris/morris.min.js"></script>
    <script src="../plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="../plugins/knob/jquery.knob.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="../plugins/daterangepicker/daterangepicker.js"></script>
    <script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <script src="../dist/js/app.min.js"></script>
    <script src="../dist/js/pages/dashboard.js"></script>
    <script src="../dist/js/demo.js"></script>
</body>

</html>
