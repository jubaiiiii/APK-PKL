<?php include "session.php"; ?>
<!DOCTYPE html>
<html>
  <?php include "head.php"; ?>
  <body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">

      <?php include "header.php"; ?>
      <?php include "menu.php"; ?>
      <?php include "waktu.php"; ?>

      <div class="content-wrapper">
        <section class="content-header">
          <h1>
            Admin
            <small>Aplikasi Invoice</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Admin</li>
          </ol>
        </section>

        <section class="content">
          <div class="row">
            <section class="col-lg-12 connectedSortable">

              <div class="box box-primary">
                <div class="box-header">
                  <i class="ion ion-clipboard"></i>
                  <h3 class="box-title">Input Data Absensi</h3>
                </div>
                <div class="box-body">
                  <div class="form-panel">
                      <form class="form-horizontal style-form" action="insert-absensi.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">ID Absensi</label>
                              <div class="col-sm-8">
                                  <input name="id_absensi" type="text" id="id_absensi" class="form-control" placeholder="ID Absensi" autofocus="on" readonly="readonly" />
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">NIK</label>
                              <div class="col-sm-8">
                                  <input name="nik" type="text" id="nik" class="form-control" placeholder="NIK" autocomplete="off" required />
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Tanggal</label>
                              <div class="col-sm-8">
                                  <input name="tanggal" type="date" id="tanggal" class="form-control" placeholder="Tanggal" autocomplete="off" required />
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Jam Masuk</label>
                              <div class="col-sm-8">
                                  <input name="jam_masuk" class="form-control" id="jam_masuk" type="time" placeholder="Jam Masuk" autocomplete="off" required />
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Jam Pulang</label>
                              <div class="col-sm-8">
                                  <input name="jam_pulang" class="form-control" id="jam_pulang" type="time" placeholder="Jam Pulang" autocomplete="off" required />
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Status</label>
                              <div class="col-sm-3">
                                <select name="status" class="form-control" required>
                                    <option value=""> -- Pilih Status -- </option>
                                    <option value="hadir">Hadir</option>
                                    <option value="izin">Izin</option>
                                    <option value="izin">Sakit</option>
                                </select>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Keterangan</label>
                              <div class="col-sm-8">
                                  <textarea name="keterangan" class="form-control" id="keterangan" placeholder="Keterangan" autocomplete="off" required></textarea>
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label"></label>
                              <div class="col-sm-10">
                                  <input type="submit" value="Simpan" class="btn btn-sm btn-primary" />&nbsp;
	                              <a href="insert-absensi.php" class="btn btn-sm btn-danger">Batal </a>
                              </div>
                          </div>
                      </form>
                  </div>
                </div>
              </div>

            </section>
          </div>
        </section>
      </div>

      <?php include "footer.php"; ?>
      <?php include "sidecontrol.php"; ?>
      <div class="control-sidebar-bg"></div>
    </div>


  </body>
</html>
