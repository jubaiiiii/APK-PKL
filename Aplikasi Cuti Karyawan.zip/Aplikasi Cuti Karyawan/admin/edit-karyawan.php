<?php
include "session.php";
include "koneksi.php"; // Sesuaikan dengan file koneksi.php atau sesuaikan cara Anda terhubung ke database
?>
<!DOCTYPE html>
<html>
<?php include "head.php"; ?>

<body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">
        <?php include "header.php"; ?>
        <?php include "menu.php"; ?>
        <?php include "waktu.php"; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    Karyawan
                    <small>Human Resource Management System</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="active">Karyawan</li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <section class="col-lg-12 connectedSortable">
                        <div class="box box-primary">
                            <div class="box-header">
                                <i class="ion ion-clipboard"></i>
                                <h3 class="box-title">Edit Data Karyawan</h3>
                                <div class="box-tools pull-right">
                                </div>
                            </div>
                            <?php
                            $kd = $_GET['kd'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM karyawan WHERE nik='$kd'");
                            if (mysqli_num_rows($sql) == 0) {
                                header("Location: karyawan.php");
                            } else {
                                $row = mysqli_fetch_assoc($sql);
                            }
                            if (isset($_POST['update'])) {
                                $nik = $_POST['nik'];
                                $nama = $_POST['nama'];
                                $jabatan = $_POST['jabatan'];
                                $status = $_POST['status'];
                                $jumlah_cuti = $_POST['jumlah_cuti'];
                                $username = $_POST['username'];
                                $password = $_POST['password'];
                                $level = $_POST['level'];
                                $gambar = $_POST['gambar'];

                                $update = mysqli_query($koneksi, "UPDATE karyawan SET nama='$nama', jabatan='$jabatan', status='$status', jumlah_cuti='$jumlah_cuti', username='$username', password='$password', level='$level', gambar='$gambar' WHERE nik='$nik'") or die(mysqli_error($koneksi));
                                if ($update) {
                                    echo "<script>alert('Data karyawan berhasil diperbaharui!')</script>";
                                    echo "<meta http-equiv='refresh' content='0; url=karyawan.php'>";
                                } else {
                                    echo "<script>alert('Data karyawan gagal diperbaharui!')</script>";
                                    echo "<h1>" . mysqli_error($koneksi) . "</h1>";
                                }
                            }
                            ?>
                            <div class="box-body">
                                <form class="form-horizontal style-form" action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">NIK</label>
                                        <div class="col-sm-8">
                                            <input name="nik" type="text" id="nik" class="form-control" placeholder="NIK" value="<?php echo $row['nik']; ?>" autofocus="on" readonly="readonly" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Nama</label>
                                        <div class="col-sm-8">
                                            <input name="nama" type="text" id="nama" class="form-control" placeholder="Nama" value="<?php echo $row['nama']; ?>" autocomplete="off" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jabatan</label>
                                        <div class="col-sm-8">
                                        <select name="jabatan" class="form-control">
                                                <option value="Staff" <?php echo ($row['jabatan'] == 'Staff') ? 'selected' : ''; ?>>Staff</option>
                                                <option value="Kadis" <?php echo ($row['jabatan'] == 'Kadis') ? 'selected' : ''; ?>>Kadis</option>
                                                <option value="Kasubbag" <?php echo ($row['jabatan'] == 'Kasubbag') ? 'selected' : ''; ?>>Kasubbag</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Status</label>
                                        <div class="col-sm-8">
                                            <select name="status" class="form-control">
                                                <option value="PNS" <?php echo ($row['status'] == 'PNS') ? 'selected' : ''; ?>>PNS</option>
                                                <option value="PPT" <?php echo ($row['status'] == 'PPT') ? 'selected' : ''; ?>>PPT</option>
                                                <option value="KONSULTAN" <?php echo ($row['status'] == 'KONSULTAN') ? 'selected' : ''; ?>>Konsultan</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jumlah Cuti</label>
                                        <div class="col-sm-8">
                                            <input name="jumlah_cuti" type="text" id="jumlah_cuti" class="form-control" value="<?php echo $row['jumlah_cuti']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Username</label>
                                        <div class="col-sm-8">
                                            <input name="username" type="text" id="username" class="form-control" value="<?php echo $row['username']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Password</label>
                                        <div class="col-sm-8">
                                            <input name="password" type="text" id="password" class="form-control" value="<?php echo $row['password']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Level</label>
                                        <div class="col-sm-8">
                                            <select name="level" class="form-control">
                                                <option value="Admin" <?php echo ($row['level'] == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                                                <option value="Atasan" <?php echo ($row['level'] == 'Atasan') ? 'selected' : ''; ?>>Atasan</option>
                                                <option value="User" <?php echo ($row['level'] == 'User') ? 'selected' : ''; ?>>User</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Gambar</label>
                                        <div class="col-sm-8">
                                            <input name="gambar" type="text" id="gambar" class="form-control" value="<?php echo $row['gambar']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label"></label>
                                        <div class="col-sm-10">
                                            <input type="submit" name="update" value="Simpan" class="btn btn-sm btn-primary" />&nbsp;
                                            <a href="karyawan.php" class="btn btn-sm btn-danger">Batal </a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </section>
        </div>

        <?php include "footer.php"; ?>
        <?php include "sidecontrol.php"; ?>
        <div class="control-sidebar-bg"></div>
    </div>

    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="../css/jquery-ui.min.js"></script>
    <script>
        $.widget.bridge('uibutton', $.ui.button);
    </script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="../plugins/morris/morris.min.js"></script>
    <script src="../plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="../plugins/knob/jquery.knob.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="../plugins/daterangepicker/daterangepicker.js"></script>
    <script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <script src="../dist/js/app.min.js"></script>
    <script src="../dist/js/pages/dashboard.js"></script>
    <script src="../dist/js/demo.js"></script>
</body>

</html>
