<?php
include "../admin/koneksi.php";

$sqlAbsensi = mysqli_query($conn, "SELECT * FROM absensi ORDER BY tanggal ASC");

?>

<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Data Absensi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style type="text/css">
        body {
            font-family: Arial;
        }

        @media print{
            .no-print{
                display: none;    
            }
        }
    </style>
</head>
<body>
    <h3 style="text-align: center;">Laporan Data Absensi</h3>
    <hr/>
    <table class="table table-striped" width="100%" border="0,5" cellspacing="0" cellpadding="4">
        <tr>
            <th>No.</th>
            <th>NIK</th>
            <th>Tanggal</th>
            <th>Jam Masuk</th>
            <th>Jam Pulang</th>
            <th>Status</th>
            <th>Keterangan</th>
        </tr>
        <?php
        $no = 1;
        while ($data = mysqli_fetch_array($sqlAbsensi)) {
            echo "<tr>
               <td>$no</td>
               <td>$data[nik]</td>
               <td>$data[tanggal]</td>
               <td>$data[jam_masuk]</td>
               <td>$data[jam_pulang]</td>
               <td>$data[status]</td>
               <td>$data[keterangan]</td>
            </tr>";
            $no++;
        }
        ?>
    </table> 

    <table width="100%" height="50%">
        <tr>
            <td></td>
            <td width="200px" height="50px">
                <p>Banjarmasin, <?php echo date('d/m/Y'); ?><br/>
                Admin,</p>
                <br/>
                <br/>
                <p>__________________</p>
                <h>Siti Zubaidah</h>
            </td>
        </tr>
    </table>        

    <button type="button" class="btn btn-primary no-print" onclick="window.print();">Cetak</button>

</body>
</html>

<?php

?>
