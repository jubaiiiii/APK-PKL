<?php
{
    include "../admin/koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cetak Laporan Data Cuti</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style type="text/css">
        body {
            font-family: Arial;
        }

        @media print{
            .no-print{
                display: none;    
            }
        }
    </style>
</head>
<body>
    <h3 style="text-align: center;">Laporan Data Cuti</h3>
    <hr/>
    <table class="table table-striped" width="100%" border="0,5" cellspacing="0" cellpadding="4">
        <tr>
            <th>No.</th>
            <th>Kode</th>
            <th>NIK</th>
            <th>Tanggal Awal</th>
            <th>Tanggal Akhir</th>
            <th>Jumlah</th>
            <th>Jenis Cuti</th>
            <th>Keterangan</th>
            <th>Status</th>
        </tr>
        <?php
        $sqlCuti = mysqli_query($conn, "SELECT * FROM cuti ORDER BY kode ASC");
        $no=1;
        while($data=mysqli_fetch_array($sqlCuti)){
            echo "<tr>
               <td>$no</td>
               <td>$data[kode]</td>
               <td>$data[nik]</td>
               <td>$data[tanggal_awal]</td>
               <td>$data[tanggal_akhir]</td>
               <td>$data[jumlah]</td>
               <td>$data[jenis_cuti]</td>
               <td>$data[ket]</td>
               <td>$data[status]</td>
            </tr>";
            $no++;
        }
        ?>
    </table> 

    <table width="100%" height="50%">
        <tr>
            <td></td>
            <td width="200px" height="50px">
                <p>Banjarmasin, <?php echo date('d/m/Y'); ?><br/>
                Admin,</p>
                <br/>
                <br/>
                <p>__________________</p>
                <h>Siti Zubaidah</h>
            </td>
        </tr>
    </table>        

    <button type="button" class="btn btn-primary no-print" onclick="window.print();">Cetak</button>

</body>
</html>

<?php
}
?>
