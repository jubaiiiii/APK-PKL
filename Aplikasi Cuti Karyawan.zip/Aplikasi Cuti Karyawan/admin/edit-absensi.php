<?php
include "session.php";
include "koneksi.php"; // Sesuaikan dengan file koneksi.php atau sesuaikan cara Anda terhubung ke database

?>
<!DOCTYPE html>
<html>
<?php include "head.php"; ?>

<body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">
        <?php include "header.php"; ?>
        <?php include "menu.php"; ?>
        <?php include "waktu.php"; ?>

        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    Absensi
                    <small>Human Resource Management System</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="active">Absensi</li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <section class="col-lg-12 connectedSortable">
                        <div class="box box-primary">
                            <div class="box-header">
                                <i class="ion ion-clipboard"></i>
                                <h3 class="box-title">Edit Data Absensi</h3>
                                <div class="box-tools pull-right">
                                </div>
                            </div>
                            <?php
                            $kd = $_GET['kd'];
                            $sql = mysqli_query($koneksi, "SELECT * FROM absensi WHERE id_absensi='$kd'");
                            if (mysqli_num_rows($sql) == 0) {
                                header("Location: absensi.php");
                            } else {
                                $row = mysqli_fetch_assoc($sql);
                            }
                            if (isset($_POST['update'])) {
                                $nik = $_POST['nik'];
                                $tanggal = $_POST['tanggal'];
                                $jam_masuk = $_POST['jam_masuk'];
                                $jam_pulang = $_POST['jam_pulang'];
                                $status = $_POST['status'];
                                $keterangan = $_POST['keterangan'];

                                $update = mysqli_query($koneksi, "UPDATE absensi SET nik='$nik', tanggal='$tanggal', jam_masuk='$jam_masuk', jam_pulang='$jam_pulang', status='$status', keterangan='$keterangan' WHERE id_absensi='$id_absensi'") or die(mysqli_error($koneksi));
                                if ($update) {
                                    echo "<script>alert('Data absensi berhasil diperbaharui!!!')</script>";
                                    echo "<meta http-equiv='refresh' content='0; url=absensi.php'>";
                                } else {
                                    echo "<script>alert('Data absensi gagal diperbaharui!!!')</script>";
                                    echo "<h1>" . mysqli_error($koneksi) . "</h1>";
                                }
                            }
                            ?>
                            <div class="box-body">
                                <form class="form-horizontal style-form" action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">ID Absensi</label>
                                        <div class="col-sm-8">
                                            <input name="id_absensi" type="text" id="id_absensi" class="form-control" placeholder="Tidak perlu di isi" value="<?php echo $row['id_absensi']; ?>" autofocus="on" readonly="readonly" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">NIK</label>
                                        <div class="col-sm-8">
                                            <input name="nik" type="text" id="nik" class="form-control" placeholder="NIK" value="<?php echo $row['nik']; ?>" autocomplete="off" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Tanggal</label>
                                        <div class="col-sm-8">
                                            <input name="tanggal" type="date" id="tanggal" class="form-control" value="<?php echo $row['tanggal']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jam Masuk</label>
                                        <div class="col-sm-8">
                                            <input name="jam_masuk" type="time" id="jam_masuk" class="form-control" value="<?php echo $row['jam_masuk']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Jam Pulang</label>
                                        <div class="col-sm-8">
                                            <input name="jam_pulang" type="time" id="jam_pulang" class="form-control" value="<?php echo $row['jam_pulang']; ?>" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Status</label>
                                        <div class="col-sm-8">
                                        <select name="status" class="form-control" required>
                                    <option value=""> -- Pilih Status -- </option>
                                    <option value="Hadir">Hadir</option>
                                    <option value="Izin">Izin</option>
                                    <option value="izin">Sakit</option>
                                </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label">Keterangan</label>
                                        <div class="col-sm-8">
                                            <input name="keterangan" type="text" id="keterangan" class="form-control" value="<?php echo $row['keterangan']; ?>" placeholder="Keterangan" autocomplete="off" required />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-2 col-sm-2 control-label"></label>
                                        <div class="col-sm-10">
                                            <input type="submit" name="update" value="Simpan" class="btn btn-sm btn-primary" />&nbsp;
                                            <a href="absensi.php" class="btn btn-sm btn-danger">Batal </a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </section>
                </div>
            </section>
        </div>

        <?php include "footer.php"; ?>
        <?php include "sidecontrol.php"; ?>
        <div class="control-sidebar-bg"></div>
    </div>

    <script src="../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="../css/jquery-ui.min.js"></script>
    <script>
        $.widget.bridge('uibutton', $.ui.button);
    </script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="../plugins/morris/morris.min.js"></script>
    <script src="../plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="../plugins/knob/jquery.knob.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="../plugins/daterangepicker/daterangepicker.js"></script>
    <script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script src="../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <script src="../plugins/fastclick/fastclick.min.js"></script>
    <script src="../dist/js/app.min.js"></script>
    <script src="../dist/js/pages/dashboard.js"></script>
    <script src="../dist/js/demo.js"></script>
</body>
</html>
