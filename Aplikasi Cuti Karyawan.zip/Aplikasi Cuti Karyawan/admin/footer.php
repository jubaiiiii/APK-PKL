<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Leave Application</b> Version  1.0.0
        </div>
        <strong> <a href="https://pupr.banjarmasinkota.go.id" target="_blank">Dinas PUPR Kota Banjarmasin &copy; 2023</a></strong>
      </footer>